# تطبيق شهادتي

تطبيق Android بسيط يعمل دون إنترنت ويعرض نسخة الويب داخل WebView.

## بناء APK مجاناً عبر GitHub Actions
1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد باسم `shahadati`.
2. افتح تبويب Actions في المستودع.
3. اختر `Build Shahadati APK` ثم `Run workflow` إذا لم يبدأ البناء تلقائياً.
4. بعد انتهاء البناء، افتح نتيجة التشغيل (Run) ونزّل Artifact باسم `Shahadati-debug-APK`.
5. فك ZIP الناتج وثبّت `app-debug.apk` على هاتف Android.

ملاحظة: هذه نسخة Debug للتجربة والتوزيع المباشر، وليست نسخة منشورة على Google Play.
